import 'package:flutter/material.dart';
import 'package:productos_app/services/auth_services.dart';

class HomeScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final authService = AuthServices(); // Instancia del servicio de autenticación

    return Scaffold(
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset(
            'assets/collage.png', // Asegúrate de tener esta imagen en assets
            fit: BoxFit.cover,
          ),
          Container(
            color: Colors.black.withOpacity(0.4), // Capa oscura para resaltar el contenido
          ),
          Center(
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16.0),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'Bienvenido al Quiz',
                    style: TextStyle(
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                      color: Colors.white,
                    ),
                    textAlign: TextAlign.center,
                  ),
                  SizedBox(height: 20),
                  Image.asset(
                    'assets/collage.png', // Tu imagen del quiz
                    height: 150,
                  ),
                  SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => QuizSelectionPage()),
                      );
                    },
                    style: ElevatedButton.styleFrom(
                      padding: EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                      backgroundColor: Colors.blueAccent,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    child: Text(
                      'Comenzar Quiz',
                      style: TextStyle(fontSize: 18),
                    ),
                  ),
                  SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () async {
                      await authService.logout(context); // Cierra sesión y redirige
                    },
                    style: ElevatedButton.styleFrom(
                      padding: EdgeInsets.symmetric(horizontal: 32, vertical: 16),
                      backgroundColor: Colors.redAccent,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    child: Text(
                      'Cerrar Sesión',
                      style: TextStyle(fontSize: 18),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}


class QuizSelectionPage extends StatelessWidget {
  // Datos para cada quiz con una imagen de fondo personalizada para cada uno.
  final List<Map<String, dynamic>> quizOptions = [
    {
      'title': 'Minecraft',
      'image': 'assets/minecraft.jpg', // Imagen de fondo para la tarjeta
      'questions': minecraftQuestions,
    },
    {
      'title': 'Fortnite',
      'image': 'assets/Fortnite.jpg',
      'questions': fortniteQuestions,
    },
    {
      'title': 'Marvel',
      'image': 'assets/marvel.jpg',
      'questions': marvelQuestions,
    },
    {
      'title': 'Disney',
      'image': 'assets/disney.jpg',
      'questions': disneyQuestions,
    },
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Selecciona un Quiz'),
        centerTitle: true,
        backgroundColor: const Color.fromARGB(255, 244, 67, 54),
      ),
      body: ListView.builder(
        padding: EdgeInsets.all(16.0),
        itemCount: quizOptions.length,
        itemBuilder: (context, index) {
          final option = quizOptions[index];
          return QuizCard(
            title: option['title'],
            backgroundImage: option['image'],
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => QuizPage(
                    title: option['title'],
                    questions: option['questions'],
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}

class QuizCard extends StatelessWidget {
  final String title;
  final String backgroundImage;
  final VoidCallback onTap;

  QuizCard({
    required this.title,
    required this.backgroundImage,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Card(
        margin: EdgeInsets.symmetric(vertical: 10),
        shape:
            RoundedRectangleBorder(borderRadius: BorderRadius.circular(15.0)),
        clipBehavior: Clip.antiAlias,
        child: Stack(
          alignment: Alignment.topCenter,
          children: [
            // Imagen de fondo
            Ink.image(
              image: AssetImage(backgroundImage),
              height: 150,
              fit: BoxFit.cover,
              child: Container(), // Necesario para que se renderice la imagen
            ),
            // Capa oscura para mejorar la visibilidad del texto
            Container(
              height: 150,
              color: Colors.black.withOpacity(0.4),
            ),
            // Título centrado en la parte superior
            Positioned(
              top: 10,
              child: Text(
                title,
                style: TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                  shadows: [
                    Shadow(
                      blurRadius: 4,
                      color: Colors.black,
                      offset: Offset(2, 2),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class QuizPage extends StatefulWidget {
  final String title;
  final List<Map<String, Object>> questions;
  QuizPage({required this.title, required this.questions});

  @override
  _QuizPageState createState() => _QuizPageState();
}

class _QuizPageState extends State<QuizPage> {
  late List<String?> selectedAnswers;

  @override
  void initState() {
    super.initState();
    _resetQuiz();
  }

  void _resetQuiz() {
    selectedAnswers =
        List<String?>.filled(widget.questions.length, null, growable: false);
  }

  void submitQuiz() {
    int score = 0;
    int total = widget.questions.length;
    for (int i = 0; i < total; i++) {
      if (selectedAnswers[i] == widget.questions[i]['correctAnswer']) {
        score++;
      }
    }
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text("Resultados"),
          content:
              Text("Respondiste correctamente $score de $total preguntas."),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context); // Cierra el diálogo
                // Reinicia el quiz: limpia las respuestas
                setState(() {
                  _resetQuiz();
                });
              },
              child: Text("Volver a intentar"),
            ),
            TextButton(
              onPressed: () {
                Navigator.pop(context); // Cierra el diálogo
                // Navega a la pantalla de selección de quiz y elimina la pila actual
                Navigator.pushAndRemoveUntil(
                  context,
                  MaterialPageRoute(builder: (context) => QuizSelectionPage()),
                  (route) => false,
                );
              },
              child: Text("Otros quizz"),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('${widget.title} Quiz'),
        centerTitle: true,
      ),
      body: ListView.builder(
        padding: EdgeInsets.all(16.0),
        itemCount: widget.questions.length + 1, // +1 para el botón de enviar
        itemBuilder: (context, index) {
          if (index == widget.questions.length) {
            return Padding(
              padding: const EdgeInsets.symmetric(vertical: 16.0),
              child: ElevatedButton(
                onPressed: submitQuiz,
                child: Text('Enviar respuestas', style: TextStyle(fontSize: 18)),
              ),
            );
          }
          var question = widget.questions[index];
          return Card(
            margin: EdgeInsets.symmetric(vertical: 8.0),
            child: Padding(
              padding: EdgeInsets.all(16.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    question['question'] as String,
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10),
                  ...(question['options'] as List<String>).map((option) {
                    return RadioListTile<String>(
                      title: Text(option),
                      value: option,
                      groupValue: selectedAnswers[index],
                      onChanged: (value) {
                        setState(() {
                          selectedAnswers[index] = value;
                        });
                      },
                    );
                  }).toList(),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}

// ======================== Preguntas de cada Quiz ========================

final List<Map<String, Object>> minecraftQuestions = [
  {
    'question': '¿Quién es el creador de Minecraft?',
    'options': ['Notch', 'Jeb', 'Markus Persson', 'Elon Musk'],
    'correctAnswer': 'Notch'
  },
  {
    'question': '¿Cuál es el mineral más raro en Minecraft?',
    'options': ['Esmeralda', 'Diamante', 'Oro', 'Hierro'],
    'correctAnswer': 'Esmeralda'
  },
  {
    'question': '¿Qué criatura explota cerca del jugador?',
    'options': ['Enderman', 'Creeper', 'Zombi', 'Araña'],
    'correctAnswer': 'Creeper'
  },
  {
    'question': '¿Cuál es el material principal para construir en Minecraft?',
    'options': ['Piedra', 'Madera', 'Arena', 'Arcilla'],
    'correctAnswer': 'Madera'
  },
  {
    'question': '¿Qué elemento se obtiene al combinar lava con agua?',
    'options': ['Piedra', 'Obsidiana', 'Grava', 'Rocas'],
    'correctAnswer': 'Obsidiana'
  },
  {
    'question': '¿Qué herramienta es necesaria para extraer diamantes?',
    'options': ['Pico de madera', 'Pico de piedra', 'Pico de hierro', 'Pico de diamante'],
    'correctAnswer': 'Pico de diamante'
  },
  {
    'question': '¿Qué bloque permite ver el exterior del edificio?',
    'options': ['Ventana', 'Puerta', 'Lámpara', 'Pared'],
    'correctAnswer': 'Ventana'
  },
  {
    'question': '¿Cuál es el objetivo principal en el modo supervivencia?',
    'options': ['Explorar', 'Construir', 'Sobrevivir', 'Recolectar recursos'],
    'correctAnswer': 'Sobrevivir'
  },
  {
    'question': '¿Qué criatura pasiva se puede domesticar en Minecraft?',
    'options': ['Lobo', 'Cerdo', 'Vaca', 'Pollo'],
    'correctAnswer': 'Lobo'
  },
  {
    'question': '¿Qué objeto se usa para encantar armas y herramientas?',
    'options': ['Mesa de trabajo', 'Horno', 'Mesa de encantamientos', 'Libro'],
    'correctAnswer': 'Mesa de encantamientos'
  },
];

final List<Map<String, Object>> fortniteQuestions = [
  {
    'question': '¿En qué año se lanzó Fortnite?',
    'options': ['2015', '2017', '2018', '2016'],
    'correctAnswer': '2017'
  },
  {
    'question': '¿Cuál es el modo más popular de Fortnite?',
    'options': ['Salvar el mundo', 'Battle Royale', 'Modo creativo', 'Eventos especiales'],
    'correctAnswer': 'Battle Royale'
  },
  {
    'question': '¿Qué recurso se usa para construir en Fortnite?',
    'options': ['Madera', 'Piedra', 'Metal', 'Todas las anteriores'],
    'correctAnswer': 'Todas las anteriores'
  },
  {
    'question': '¿Cómo se llama la tormenta que cierra el juego?',
    'options': ['La Zona', 'El Círculo', 'La Tormenta', 'La Tempestad'],
    'correctAnswer': 'La Tormenta'
  },
  {
    'question': '¿Qué objeto es icónico para lanzar al enemigo en Fortnite?',
    'options': ['Llamarada', 'Lanzacohetes', 'Granada', 'Pico'],
    'correctAnswer': 'Pico'
  },
  {
    'question': '¿Cuál es el objetivo principal en Fortnite Battle Royale?',
    'options': ['Construir la base más grande', 'Ser el último en pie', 'Recolectar recursos', 'Explorar el mapa'],
    'correctAnswer': 'Ser el último en pie'
  },
  {
    'question': '¿Qué personaje emblemático ha sido parte de colaboraciones en Fortnite?',
    'options': ['Thanos', 'John Wick', 'Deadpool', 'Nadie'],
    'correctAnswer': 'John Wick'
  },
  {
    'question': '¿Cómo se llama el sistema de progresión en Fortnite?',
    'options': ['Battle Pass', 'Level Up', 'Season Pass', 'XP Tracker'],
    'correctAnswer': 'Battle Pass'
  },
  {
    'question': '¿Qué modo permite a los jugadores crear sus propias islas?',
    'options': ['Modo creativo', 'Battle Royale', 'Salvar el mundo', 'Aventura'],
    'correctAnswer': 'Modo creativo'
  },
  {
    'question': '¿Qué recurso es esencial para reparar estructuras?',
    'options': ['Madera', 'Piedra', 'Metal', 'Ninguno'],
    'correctAnswer': 'Metal'
  },
];

final List<Map<String, Object>> marvelQuestions = [
  {
    'question': '¿Quién es el líder de los Vengadores?',
    'options': ['Iron Man', 'Capitán América', 'Thor', 'Hulk'],
    'correctAnswer': 'Capitán América'
  },
  {
    'question': '¿Cuál es el verdadero nombre de Iron Man?',
    'options': ['Steve Rogers', 'Tony Stark', 'Bruce Banner', 'Peter Parker'],
    'correctAnswer': 'Tony Stark'
  },
  {
    'question': '¿Qué dios nórdico es interpretado por Thor?',
    'options': ['Odin', 'Loki', 'Thor', 'Heimdall'],
    'correctAnswer': 'Thor'
  },
  {
    'question': '¿Quién se transforma en Hulk al enojarse?',
    'options': ['Bruce Banner', 'Tony Stark', 'Steve Rogers', 'Natasha Romanoff'],
    'correctAnswer': 'Bruce Banner'
  },
  {
    'question': '¿Cuál es el nombre del martillo de Thor?',
    'options': ['Stormbreaker', 'Mjolnir', 'Gungnir', 'Excalibur'],
    'correctAnswer': 'Mjolnir'
  },
  {
    'question': '¿Qué equipo reúne a varios superhéroes de Marvel?',
    'options': ['X-Men', 'Los Vengadores', 'Los Cuatro Fantásticos', 'Defensores'],
    'correctAnswer': 'Los Vengadores'
  },
  {
    'question': '¿Quién es conocido como el “Hombre Araña”?',
    'options': ['Iron Man', 'Spider-Man', 'Ant-Man', 'Wasp'],
    'correctAnswer': 'Spider-Man'
  },
  {
    'question': '¿En qué ciudad se desarrolla gran parte del universo Marvel?',
    'options': ['Gotham', 'Metrópolis', 'Nueva York', 'Central City'],
    'correctAnswer': 'Nueva York'
  },
  {
    'question': '¿Qué personaje usa un escudo como arma principal?',
    'options': ['Iron Man', 'Capitán América', 'Hawkeye', 'Black Panther'],
    'correctAnswer': 'Capitán América'
  },
  {
    'question': '¿Cuál es la gema del tiempo en el Universo Cinematográfico de Marvel?',
    'options': ['Gema del Poder', 'Gema del Tiempo', 'Gema de la Realidad', 'Gema del Espacio'],
    'correctAnswer': 'Gema del Tiempo'
  },
];

final List<Map<String, Object>> disneyQuestions = [
  {
    'question': '¿Cuál fue la primera película de animación de Disney?',
    'options': ['La Bella Durmiente', 'Blancanieves', 'Cenicienta', 'Pinocho'],
    'correctAnswer': 'Blancanieves'
  },
  {
    'question': '¿En qué película aparece el personaje Simba?',
    'options': ['Bambi', 'El Rey León', 'La Sirenita', 'Aladdín'],
    'correctAnswer': 'El Rey León'
  },
  {
    'question': '¿Cuál es la princesa que pierde su zapato de cristal?',
    'options': ['Aurora', 'Bella', 'Cenicienta', 'Ariel'],
    'correctAnswer': 'Cenicienta'
  },
  {
    'question': '¿Qué animal es el mejor amigo de Aladdín?',
    'options': ['Un tigre', 'Un mono', 'Un loro', 'Un perro'],
    'correctAnswer': 'Un mono'
  },
  {
    'question': '¿Cómo se llama la muñeca en la película "Toy Story"?',
    'options': ['Jessie', 'Barbie', 'Woody', 'Bo Peep'],
    'correctAnswer': 'Woody'
  },
  {
    'question': '¿Qué película de Disney tiene un villano llamado Úrsula?',
    'options': ['La Bella y la Bestia', 'La Sirenita', 'Mulan', 'Pocahontas'],
    'correctAnswer': 'La Sirenita'
  },
  {
    'question': '¿Cuál es la ciudad ficticia en "Zootopia"?',
    'options': ['Ciudad Animal', 'Zootopia', 'Critter City', 'Furtropolis'],
    'correctAnswer': 'Zootopia'
  },
  {
    'question': '¿Qué objeto mágico usa Elsa en "Frozen"?',
    'options': ['Un cetro', 'Una corona', 'Su poder de hielo', 'Un espejo mágico'],
    'correctAnswer': 'Su poder de hielo'
  },
  {
    'question': '¿Qué animal acompaña a Dumbo?',
    'options': ['Una hormiga', 'Una ratón', 'Un pájaro', 'Un elefante'],
    'correctAnswer': 'Una ratón'
  },
  {
    'question': '¿En qué película aparece la canción "Hakuna Matata"?',
    'options': ['El Rey León', 'Mulan', 'Pocahontas', 'La Bella y la Bestia'],
    'correctAnswer': 'El Rey León'
  },
];

